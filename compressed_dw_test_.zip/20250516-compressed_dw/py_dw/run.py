import time
import glob

from ase import io, Atoms
import numpy as np

from deepmd.infer import DeepDipole


def run(
    atoms: Atoms,
    dw_model: str,
    n_loop: int = 10,
):
    dp = DeepDipole(dw_model)
    type_map = dp.get_type_map()

    atype = np.zeros(len(atoms), dtype=int)
    for ii, _atype in enumerate(type_map):
        atype[atoms.symbols == _atype] = ii

    ts = []
    for _ in range(n_loop):
        t = time.perf_counter()
        dp.eval(
            atoms.get_positions().reshape(1, -1),
            atoms.get_cell().reshape(1, -1),
            atype,
        )
        ts.append(time.perf_counter() - t)
    return np.array(ts)


if __name__ == "__main__":
    fnames = glob.glob("../configs/*.xyz")
    fnames.sort()
    for ii, fname in enumerate(fnames):
        atoms = io.read(fname)
        out = run(atoms, "../dw_model.pb", 100)
        np.savetxt("dw.%03d.out" % ii, out)

        out = run(atoms, "../dw_compressed_model.pb", 100)
        np.savetxt("dw-compressed.%03d.out" % ii, out)
