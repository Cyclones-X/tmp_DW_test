import glob
import os

from ase import io


fnames = glob.glob("../configs/coord.*.xyz")
fnames.sort()
for ii, fname in enumerate(fnames):
    atoms = io.read(fname)

    dname = f"original.{ii:03d}"
    os.makedirs(dname, exist_ok=True)
    io.write(
        os.path.join(dname, "system.data"),
        atoms,
        format="lammps-data",
        specorder=["O", "H"],
    )
    os.symlink(os.path.abspath("../graph.pb"), os.path.join(dname, "graph.pb"))
    os.symlink(os.path.abspath("../dw_model.pb"), os.path.join(dname, "dw_model.pb"))
    os.symlink(os.path.abspath("input.lmp"), os.path.join(dname, "input.lmp"))

    os.chdir(dname)
    os.system("lmp -i input.lmp")
    os.chdir("../")

    dname = f"compressed.{ii:03d}"
    os.makedirs(dname, exist_ok=True)
    io.write(
        os.path.join(dname, "system.data"),
        atoms,
        format="lammps-data",
        specorder=["O", "H"],
    )
    os.symlink(os.path.abspath("../graph.pb"), os.path.join(dname, "graph.pb"))
    os.symlink(
        os.path.abspath("../dw_compressed_model.pb"), os.path.join(dname, "dw_model.pb")
    )
    os.symlink(os.path.abspath("input.lmp"), os.path.join(dname, "input.lmp"))

    os.chdir(dname)
    os.system("lmp -i input.lmp")
    os.chdir("../")
