import time

import glob

from ase import io, Atoms
import numpy as np

from deepmd.infer.data_modifier import DipoleChargeModifier


def run(
    atoms: Atoms,
    dw_model: str,
    n_loop: int = 10,
):
    dm = DipoleChargeModifier(
        dw_model,
        model_charge_map=[-8],
        sys_charge_map=[6, 1],
        ewald_beta=0.4,
        ewald_h=0.5,
    )
    type_map = dm.get_type_map()

    atype = np.zeros(len(atoms), dtype=int)
    for ii, _atype in enumerate(type_map):
        atype[atoms.symbols == _atype] = ii

    ts_total = []
    ts_ewald = []
    for _ in range(n_loop):
        t = time.perf_counter()
        dm.eval(
            atoms.get_positions().reshape(1, -1),
            atoms.get_cell().reshape(1, -1),
            atype,
            eval_fv=True,
        )
        ts_total.append(time.perf_counter() - t)

        t = time.perf_counter()
        dm.eval(
            atoms.get_positions().reshape(1, -1),
            atoms.get_cell().reshape(1, -1),
            atype,
            eval_fv=False,
        )
        ts_ewald.append(time.perf_counter() - t)

    return np.array(ts_total), np.array(ts_ewald)


if __name__ == "__main__":
    fnames = glob.glob("../configs/*.xyz")
    fnames.sort()
    for ii, fname in enumerate(fnames):
        atoms = io.read(fname)
        out = run(atoms, "../dw_model.pb", 50)
        # print(out[0] - out[1])
        np.savetxt(
            "dw.%03d.out" % ii, np.transpose([out[0], out[1]]), header="total ewald"
        )

        out = run(atoms, "../dw_compressed_model.pb", 50)
        # print(out[0] - out[1])
        np.savetxt(
            "dw-compressed.%03d.out" % ii,
            np.transpose([out[0], out[1]]),
            header="total ewald",
        )
